package com.coder.house.ventas.online.ventasonline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VentasOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
